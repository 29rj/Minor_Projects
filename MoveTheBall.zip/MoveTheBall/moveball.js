// var ballId = document.querySelector("#ball");

var id2 = document.getElementById("ball");

console.log(id2.style.height);

// console.log(ballId.getAttribute("height"));

var keyPress = document.addEventListener("keypress",function(e){
	console.log(e.key);

	// if(e.key == 'w'){

	// }
});

